public class Decafeine extends Cafe { 
  public Decafeine() {
    super("d�caf�in�");
  }
  public double prix() { 
    return 0.40;
  }
}
