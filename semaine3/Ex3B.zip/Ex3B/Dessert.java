public class Dessert extends Cafe { 
  public Dessert() {
    super("dessert");
  }
  public double prix() { 
    return 0.37;
  }
} 
