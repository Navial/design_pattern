public class Moka extends Cafe { 
  public Moka() {
    super("moka");
  }
  public double prix() { 
    return 0.35;
  }
}
