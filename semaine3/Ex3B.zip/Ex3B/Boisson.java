public interface Boisson {
  public abstract String getNom(); 
  public abstract double prix();
}
