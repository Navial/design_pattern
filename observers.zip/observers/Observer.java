public interface Observer {

    public void traterLigne(String ligne);

    public void printResult();
}
